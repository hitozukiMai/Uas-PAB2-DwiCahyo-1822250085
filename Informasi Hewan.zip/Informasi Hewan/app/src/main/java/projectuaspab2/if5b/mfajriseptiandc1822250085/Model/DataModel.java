package projectuaspab2.if5b.mfajriseptiandc1822250085.Model;

public class DataModel {
    private int id;
    private String nama,spesies,habitat,ilmiah,pernapasan;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getSpesies() {
        return spesies;
    }

    public void setSpesies(String spesies) {
        this.spesies = spesies;
    }

    public String getHabitat() {
        return habitat;
    }

    public void setHabitat(String habitat) {
        this.habitat = habitat;
    }

    public String getIlmiah() {
        return ilmiah;
    }

    public void setnIlmiah(String ilmiah) {
        this.ilmiah = ilmiah;
    }

    public String getPernapasan() {
        return pernapasan;
    }

    public void setPernapasan(String pernapasan) {
        this.pernapasan = pernapasan;
    }
}
